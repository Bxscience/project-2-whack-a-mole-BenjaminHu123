package com.example.benja.whackamole

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.support.v4.app.INotificationSideChannel
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import org.w3c.dom.Text
import java.sql.Time
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.system.measureTimeMillis
import android.content.Intent

class FourthActivity : AppCompatActivity() {
    lateinit var scoreText:TextView
    lateinit var textTime: TextView
    lateinit var pup1: ImageView
    lateinit var pup2: ImageView
    lateinit var pup3: ImageView
    lateinit var pup4: ImageView
    lateinit var pup5: ImageView
    lateinit var pup6: ImageView
    lateinit var pup7: ImageView
    lateinit var pup8: ImageView
    lateinit var pup9: ImageView
    lateinit var pup10: ImageView
    lateinit var pup11: ImageView
    lateinit var pup12: ImageView

    private var score: Int = 0
    private lateinit var timer: CountDownTimer
    private lateinit var timer2: CountDownTimer
    private var secondsRemaining: Long = 60L
    private var pupChosen: ImageView ?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fourth)

        scoreText = findViewById(R.id.score)
        textTime = findViewById(R.id.time)
        pup1 = findViewById<ImageView>(R.id.pup1)
        pup2 = findViewById<ImageView>(R.id.pup2)
        pup3 = findViewById<ImageView>(R.id.pup3)
        pup4 = findViewById<ImageView>(R.id.pup4)
        pup5 = findViewById<ImageView>(R.id.pup5)
        pup6 = findViewById<ImageView>(R.id.pup6)
        pup7 = findViewById<ImageView>(R.id.pup7)
        pup8 = findViewById<ImageView>(R.id.pup8)
        pup9 = findViewById<ImageView>(R.id.pup9)
        pup10 = findViewById<ImageView>(R.id.pup10)
        pup11 = findViewById<ImageView>(R.id.pup11)
        pup12 = findViewById<ImageView>(R.id.pup12)
        startTimer() // 60 second timer
        pickMole() //starts the recursion process
    }

    private fun pupClicked(){
        timer2.cancel()
        pupChosen!!.visibility = View.INVISIBLE
        score++
        scoreText.text = "Score: " + score
        pickMole()
    }
    private fun pickMole(){
        when (Random().nextInt(12)+1) {
            1 -> pupChosen = pup1
            2 -> pupChosen = pup2
            3 -> pupChosen = pup3
            4 -> pupChosen = pup4
            5 -> pupChosen = pup5
            6 -> pupChosen = pup6
            7 -> pupChosen = pup7
            8 -> pupChosen = pup8
            9 -> pupChosen = pup9
            10 -> pupChosen = pup10
            11 -> pupChosen = pup11
            12 -> pupChosen = pup12
        }
        pupChosen!!.setOnClickListener {
            pupClicked()
        }
        pupChosen!!.visibility = View.VISIBLE
        timer2 = object: CountDownTimer( 750, 750){
            override fun onFinish() {
                pupChosen!!.visibility = View.INVISIBLE
                pickMole()
            }
            override fun onTick(millisUntilFinished: Long) { }
        }.start()
        //pupChosen works bec it copies reference
        //since they are objects
    }

    private fun startTimer(){
        timer = object: CountDownTimer(60 * 1000, 1000){
            override fun onFinish() {
                onTimerFinished()
            }
            override fun onTick(millisUntilFinished: Long) {
                secondsRemaining = millisUntilFinished/1000
                textTime.text = "Time: " + secondsRemaining
            }
        }.start()
    }

    private fun onTimerFinished(){
        textTime.text = "Done"
        timer2.cancel()
        val intent = Intent(this@FourthActivity, ResultActivity::class.java)
        intent.putExtra("Score", ""+score)
        startActivity(intent)
    }
}