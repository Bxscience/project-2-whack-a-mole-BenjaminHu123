package com.example.benja.whackamole

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val btn = findViewById<Button>(R.id.btnGoBack)
        val scoreText = findViewById<TextView>(R.id.finalScore)
        btn.setOnClickListener {
            val intent = Intent(this@ResultActivity, StartingActivity::class.java)
            startActivity(intent)
        }
        var intent = intent
        val score: String = intent.getStringExtra("Score")

        scoreText.text = "Score: " + score
    }
}
