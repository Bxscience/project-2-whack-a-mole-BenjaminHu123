package com.example.benja.whackamole

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class StartingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_starting)

        /*The variable names come from the number in front e.g: 2 x 3, 3 x 3, 4 x 3
        * initialize*/
        val btn2 = findViewById<Button>(R.id.btn1)
        val btn3 = findViewById<Button>(R.id.btn2)
        val btn4 = findViewById<Button>(R.id.btn3)

        btn2.setOnClickListener {
            val intent = Intent(this@StartingActivity,SecondActivity::class.java)
            startActivity(intent)
        }

        btn3.setOnClickListener {
            val intent = Intent(this@StartingActivity,ThirdActivity::class.java)
            startActivity(intent)
        }

        btn4.setOnClickListener {
            val intent = Intent(this@StartingActivity,FourthActivity::class.java)
            startActivity(intent)
        }
    }
}
